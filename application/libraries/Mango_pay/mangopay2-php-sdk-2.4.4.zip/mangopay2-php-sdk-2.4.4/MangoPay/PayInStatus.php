<?php
namespace MangoPay;

/**
 * PayIn statuses
 */
class PayInStatus
{
    const Created = 'CREATED';
    const Succeeded = 'SUCCEEDED';
    const Failed = 'FAILED';
}
