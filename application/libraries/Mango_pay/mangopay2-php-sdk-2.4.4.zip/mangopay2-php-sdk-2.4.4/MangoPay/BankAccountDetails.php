<?php
namespace MangoPay;

/**
 * Marker interface for classes with details option in BankAccount entity
 */
interface BankAccountDetails
{
}
