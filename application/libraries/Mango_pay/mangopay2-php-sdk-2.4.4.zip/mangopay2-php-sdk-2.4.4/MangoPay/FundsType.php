<?php
namespace MangoPay;

/**
 * Funds types
 */
class FundsType
{
    /**
    * Fees type
    */ 
    const FEES = "FEES";
    
    /**
     * Credit type
     */
    const CREDIT = "CREDIT";
}