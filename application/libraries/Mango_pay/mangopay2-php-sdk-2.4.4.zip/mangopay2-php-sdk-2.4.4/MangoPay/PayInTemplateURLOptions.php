<?php
namespace MangoPay;

/**
 * Class represents template URL options
 */
class PayInTemplateURLOptions extends Libraries\Dto
{
    /**
     * PAYLINE options
     *
     * @var string
     */
    public $PAYLINE;
}
