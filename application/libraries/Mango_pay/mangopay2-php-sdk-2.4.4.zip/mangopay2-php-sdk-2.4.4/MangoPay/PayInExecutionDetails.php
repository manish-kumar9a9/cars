<?php
namespace MangoPay;

/**
 * Marker interface for classes with details of execution option in PayIn entity
 */
interface PayInExecutionDetails
{
}
