<?php
namespace MangoPay;

/**
 * PayOut statuses
 */
class PayOutStatus
{
    const Created = 'CREATED';
    const Succeeded = 'SUCCEEDED';
    const Failed = 'FAILED';
}
