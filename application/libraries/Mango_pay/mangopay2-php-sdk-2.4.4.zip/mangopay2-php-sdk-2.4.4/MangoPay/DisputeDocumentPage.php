<?php
namespace MangoPay;

/**
 * Dispute document page entity for dispute document
 */
class DisputeDocumentPage extends Libraries\Upload
{
}
