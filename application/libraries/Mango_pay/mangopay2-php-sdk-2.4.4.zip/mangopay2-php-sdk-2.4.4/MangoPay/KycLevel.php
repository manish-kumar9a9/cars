<?php
namespace MangoPay;

/**
 * KYC Level
 */
class KycLevel
{
    const Light = 'LIGHT';
    const Regular = 'REGULAR';
}
