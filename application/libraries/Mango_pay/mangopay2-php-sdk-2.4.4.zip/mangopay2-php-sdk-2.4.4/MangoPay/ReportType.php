<?php
namespace MangoPay;

class ReportType
{
    const Transactions = 'TRANSACTIONS';
}
