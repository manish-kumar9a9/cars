<?php
namespace MangoPay;

/**
 * PayIn execution types
 */
class PayInExecutionType
{
    const Direct = 'DIRECT';
    const Web = 'WEB';
}
