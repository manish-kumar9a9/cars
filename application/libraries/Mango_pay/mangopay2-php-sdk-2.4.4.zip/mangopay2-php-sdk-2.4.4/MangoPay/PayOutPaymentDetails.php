<?php
namespace MangoPay;

/**
 * Marker interface for classes with details of means of payment in PayOut entity
 */
interface PayOutPaymentDetails
{
}
