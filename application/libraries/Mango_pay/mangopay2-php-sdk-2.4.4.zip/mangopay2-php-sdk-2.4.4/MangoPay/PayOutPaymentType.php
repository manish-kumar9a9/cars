<?php
namespace MangoPay;

/**
 * PayOut payment types
 */
class PayOutPaymentType
{
    const BankWire = 'BANK_WIRE';
}
