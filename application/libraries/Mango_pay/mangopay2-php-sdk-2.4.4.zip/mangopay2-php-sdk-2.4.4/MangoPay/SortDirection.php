<?php
namespace MangoPay;

class SortDirection
{
    const DESC = 'desc';
    const ASC = 'asc';
}
