<?php
namespace MangoPay;

/**
 * Client logo upload entity
 */
class ClientLogoUpload extends Libraries\Upload
{
}
