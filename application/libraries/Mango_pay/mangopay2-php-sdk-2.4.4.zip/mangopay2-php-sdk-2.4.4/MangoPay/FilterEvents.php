<?php
namespace MangoPay;

/**
 * Filter for event list
 */
class FilterEvents extends FilterBase
{
    /**
     * Event type
     * @var \MangoPay\EventType
     */
    public $EventType;
}
