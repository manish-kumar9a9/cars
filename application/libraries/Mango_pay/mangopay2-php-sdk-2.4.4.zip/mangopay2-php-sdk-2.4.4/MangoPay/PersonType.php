<?php
namespace MangoPay;

/**
 * Person type for users
 */
class PersonType
{
    const Natural = 'NATURAL';
    const Legal = 'LEGAL';
}
