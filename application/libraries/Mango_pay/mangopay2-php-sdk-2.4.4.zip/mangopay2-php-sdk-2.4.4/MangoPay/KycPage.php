<?php
namespace MangoPay;

/**
 * KYC page entity for Kyc document
 */
class KycPage extends Libraries\Upload
{
}
