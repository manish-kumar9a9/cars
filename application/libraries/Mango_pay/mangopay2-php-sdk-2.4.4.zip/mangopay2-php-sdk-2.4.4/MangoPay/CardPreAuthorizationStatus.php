<?php
namespace MangoPay;

/**
 * Pre-authorization statuses
 */
class CardPreAuthorizationStatus
{
    const Created = 'CREATED';
    const Succeeded = 'SUCCEEDED';
    const Failed = 'FAILED';
}
