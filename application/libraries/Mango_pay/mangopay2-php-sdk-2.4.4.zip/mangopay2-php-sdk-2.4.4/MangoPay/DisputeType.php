<?php
namespace MangoPay;

/**
 * Dispute types
 */
class DisputeType
{
    const Contestable = "CONTESTABLE";
    const NotContestable = "NOT_CONTESTABLE";
    const Retrieval = "RETRIEVAL";
}
