<?php
namespace MangoPay;

class CardValidity
{
    const Unknown = 'UNKNOWN';
    const Valid = 'VALID';
    const Invalid = 'INVALID';
}
