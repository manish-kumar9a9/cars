<?php

namespace MangoPay\Libraries;

/**
 * Abstract class for all documents
 */
abstract class Upload extends Dto
{
    
    /**
     * Image base64
     * @var string
     */
    public $File;
}
