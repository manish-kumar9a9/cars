<?php
namespace MangoPay\Libraries;

class Exception extends \Exception
{
}
