<?php
namespace MangoPay;

/**
 * Legal Person types
 */
class LegalPersonType
{
    const Business = 'BUSINESS';
    const Organization = 'ORGANIZATION';
    const Soletrader = 'SOLETRADER';
}
