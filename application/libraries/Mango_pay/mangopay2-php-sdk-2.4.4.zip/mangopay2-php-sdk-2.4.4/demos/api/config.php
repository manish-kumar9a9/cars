<?php

/**
 * Setting for client: client Id, client password
 */
define('MangoPayDemo_BaseUrl', 'https://api.sandbox.mangopay.com');
define('MangoPayDemo_ClientId', 'sdk-unit-tests');
define('MangoPayDemo_ClientPassword', 'cqFfFrWfCcb7UadHNxx2C9Lo6Djw8ZduLi7J9USTmu8bhxxpju');

/**
 * Path to folder to store temporary files (with permissions to write)
 */
define('MangoPayDemo_TemporaryFolder', __dir__);