$(document).ready(function(){

	$("#menu").accordion( { active: selectedModuleIndex >= 0 ? selectedModuleIndex : false, collapsible : true, heightStyle: "content" } );

});