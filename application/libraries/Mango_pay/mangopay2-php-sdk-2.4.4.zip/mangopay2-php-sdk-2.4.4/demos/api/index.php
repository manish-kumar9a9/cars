<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
        <title>MangoPay API - demo</title>
        <link rel="stylesheet" href="demo.css" />
        <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
        <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
        <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
        <script src="demo.js"></script>
    </head>
    <body>
        <table border="0" width="870">
            <tr>
                <td style="width: 250px" valign="top"><?php require_once 'menu.php'; ?></td>
                <td style="width: 20px"></td>
                <td style="width: 600px; padding: 0px;" valign="top"><?php require_once 'form.php'; ?></td>
            </tr>
        </table>
    </body>
</html>
